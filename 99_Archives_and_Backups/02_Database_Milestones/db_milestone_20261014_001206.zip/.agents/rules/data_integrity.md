# Rule: Excel Coding Sheet Data Integrity

This document defines the strict data type policies, template schemas, and evidence standards for all BSMA coding sheets.

---

## 1. Universal Zero Guesswork & Dual Missing Data Protocol (Rule 1)
- **Absolute Prohibition on Imputation (Zero Guesswork):** Never guess, fabricate, or impute data. Do NOT calculate averages or deduce missing values under any circumstances.
- **Dual Missing Data Protocol (Numeric 999 vs. Clean Blank Text):**
  - **Numeric Missing Values (Cols 17–50):** Whenever an empirical numeric metric is missing or not reported in the paper (Mean Age [Col 23], % Female [Col 24], Org Tenure [Col 25], Number of Items [Cols 27 & 34], Min/Max Likert Anchors [Cols 28, 29, 35, 36], Mean [Cols 42 & 46], SD [Cols 43 & 47], Reliability/Alpha [Cols 44 & 48]), YOU MUST enter the integer `999`. This ensures statistical analysis software (R, SPSS, CMA, Stata) can unambiguously identify missing data.
  - **Text / Categorical Non-Applicable Fields:** Non-applicable or unneeded text cells (`Reason for Exclusion` for included papers, `Other (specify)`, `Report Type Note`, `Notes`, and `Article Descriptors`) MUST be left as clean BLANK cells (`None`). Writing `"Not Reported"` into Excel cells is strictly prohibited to eliminate visual clutter.
  - **Excluded Papers (Code 0):** Terminate immediately at Col 6 (`Reason for Exclusion`), leaving all subsequent columns (Cols 7–50) as clean BLANK cells (`None`), mirroring Paper #66 in `49_53_66.xlsx`.

---

## 2. Template Structure & Format Compliance (Rules 3, 6, 19)
- **Universal Master Insertion (Rule 6):** ALL successfully processed papers MUST be injected into `03_Coding_Sheets/BSMA_Master_Coding_Sheet.xlsx`. Every paper must retain its assigned BSMA ID.
- **50-Column Full Extraction Schema (Rule 19):** `03_Coding_Sheets/BSMA_Master_Coding_Sheet.xlsx` is the ultimate master template and contains the 50-column "Full Text Data Extraction" structure (Columns A through AX, covering Study/Sample Descriptors and Measure Descriptors).
- **Screening vs Extraction Sheet Separation (Rule 19):**
  - **Screening Master (`BSMA_Master_Coding_Sheet.xlsx`):** Retains full bibliographic metadata in Cols 1–16 (Article ID, Judgments, Reasons, Abstract, Title, Authors, Year, Notes) as the permanent screening record.
  - **Extraction Batch Sheets (`[start]_[end].xlsx`):** Dedicated full-text extraction sheets eliminate bibliographic redundancy:
    - `Col 3 (Sample ID)`: Left blank (`None`).
    - `Cols 7–16 (Article Descriptors)`: Left completely blank (`None`) because this metadata is already preserved in the screening database.
    - `Included Papers (1 = include)`: Data population strictly begins at **Col 17 (Study/Sample Descriptors)** through Col 50 (`Effect Size`).
    - `Excluded Papers (0 = exclude)`: Terminate immediately after **Col 6 (`Reason for Exclusion`)**, leaving all subsequent columns (Cols 7–50) completely blank (`None`).
- **Prohibition of Bold Headers (Rule 3):** Never use markdown bold (`**`) or rich text bolding inside Excel header cells.

---

## 3. Verbatim Quote Evidence Standards (Rule 13)
- **Mandatory Quote Injection:** Whenever a paper is judged—whether `1 = Include` or `0 = Exclude`—you MUST extract and inject exact, character-for-character verbatim quotes from the PDF text into Col 16 (Notes).
- **Strict Prohibition of Ellipses (No Truncation):** NEVER use ellipses (`...`) to summarize, abbreviate, or truncate sentences. You must extract full, complete sentences or paragraphs exactly as they appear in the original text.
- **Maximum Multi-Section Evidence:** Collect the maximum evidence possible from multiple sections (Abstract, Participants, Measures, Discussion) to robustly prove the sample type or exclusion reason.
- **Exact Note Format:** Use brackets to indicate the section of each quote:  
  `[Reason summary]. Verbatim Evidence: "[Section 1] <exact quote 1>" [Section 2] "<exact quote 2>"`

---

## 4. Verbatim Variable & Measure Naming Standards (Rule 14)
- **Table Axis Variable Name Fidelity & Index Number Pruning (Cols 41 & 45):** 
  - Variable names for Boundary Spanning Behavior (Col 41) and Non-BS Variables (Col 45) MUST character-for-character preserve the author's exact phrasing, internal/external sub-construct specifiers (e.g., `"Internal COBSB"`, `"External COBSB"`, `"Internal Com."`, `"External Com."`), and published abbreviations (e.g., `"BSA"`, `"Org. Comm."`, `"Dual Comm."`).
  - **Table Layout Index Pruning:** Leading numbering prefixes (e.g., `"1. "`, `"2) "`, `"(3) "`, `"10. "`) that serve purely as table matrix row/column layout indices MUST be automatically pruned. Such numbers are indexing coordinates, not theoretical construct names. The full original coordinate with number is permanently preserved in Col 50 Notes / `cell_proof` (e.g., `Row: 7. Status, Col: 1`).
  - **Prohibition of Post-Hoc Normalization:** NEVER paraphrase, expand, translate, or "beautify" table variable names (e.g., never arbitrarily convert `"Ext. Comm."` to `"External Communication Behavior"`).
- **Methodology Specific Measure Substring Fidelity (Cols 32 & 39):**
  - The `Specific Measure Used` field for BSB (Col 32) and Non-BS Variables (Col 39) MUST be an exact, unmodified substring of the methodology quote (`source_quote`), capturing the precise validated instrument or scale author citation (e.g., `"Bettencourt et al. (2005)"`, `"Rizzo, House, and Lirtzman (1970)"`).
  - Never guess or construct synthetic instrument names when the author's exact phrasing is available in the text.

---

## 5. Hierarchical 3-Tier Header Protocol (Rule 20)
- **Canonical 3-Tier Structure (Rows 1–3):** ALL Excel coding sheets (batch sheets, paper extracts, master sheets) MUST strictly implement the canonical 3-tier hierarchical header structure:
  - **Row 1 (Section Category):** Section groupings (`Coder Initials`, `Sample ID`, `Effect size ID`, `Inclusion-Exclusion Judgment`, `Reason for Exclusion`, `Article Descriptors`, `Study/Sample Descriptors`, `Measure Descriptors`, `Effect Size`).
  - **Row 2 (Sub-category):** Operational sub-constructs (`Boundary spanning`, `Non-boundary-spanning variable`, `Correlation r`, `Notes`).
  - **Row 3 (Leaf Column Header):** Leaf column names (`Abstract`, `Title`, `Publication Name`, `Authors`, `Year`, ..., `Name`, `Mean`, `SD`, `Reliability (Alpha)`).
  - **Row 4+:** Data rows strictly begin at Row 4.
- **Strict Prohibition of Pandas Flat Header Exports:** NEVER use raw `pandas.DataFrame.to_excel()` to export or overwrite coding sheets. Doing so treats merged/empty cells in Row 1 as missing column labels, injecting corrupted `'Unnamed: X'` headers and destroying the 3-tier hierarchy.
- **Template Inheritance via OpenPyXL:** All new or updated extraction sheets MUST be initialized via `excel_template_util.py` or cloned from the canonical template `03_Coding_Sheets/49_53_66.xlsx`, copying merged cell ranges, fonts, fills, alignments, and column dimensions with openpyxl.

---

## 6. Effect Size Coordinates, Provenance & Verbatim Audit Protocol (Rule 9 / Col 50 Notes)
To ensure that any researcher can cross-verify effect sizes directly against the source PDF in under 3 seconds without manual page scanning, **Col 50 (Notes)** must strictly follow this unified provenance schema:
- **Mandatory Table & Page Coordinate Prefix:** Every extracted correlation MUST begin with its exact physical table number and manuscript/PDF page:  
  `Table X (p. Y), Row: <row_header_quote>, Col: <col_header_quote>, Raw: <raw_cell_value>`
- **Mandatory Verbatim Provenance for Methodological Flags (Rule 13 Integration):** When special methodological conditions occur, a pipe (`|`) delimiter MUST be appended followed by the explicit flag and the exact, character-for-character verbatim sentence or footnote from the paper proving the condition:
  - **Latent Variable Correlation:** When correlations are based on CFA/SEM latent constructs rather than raw observed scores:  
    `... | Latent correlation: [<Table/Page/Section>] "<exact verbatim sentence or footnote proving latent structure/AVE diagonal>"`
  - **Global Composite BSB Score:** When the measure combines multiple sub-dimensions into an overall composite score:  
    `... | Global composite: [<Section, p. Y>] "<exact verbatim sentence defining how the composite/mean rank was calculated>"`
  - **Sample Size / Pairwise N Discrepancy:** When matrix sample size differs from the text or is a pairwise range:  
    `... | Sample N footnote: [<Table Footnote>] "<exact verbatim footnote sentence detailing effective N>"`
  - **Partial / Imputed Correlation:** When correlations control for covariates or use imputed data:  
    `... | Partial correlation: [<Table Footnote>] "<exact verbatim footnote explaining controls>"`
- **Prohibition of Naked Labels:** Never enter naked flags (e.g., writing only `"Based on latent variables"` or `"Global composite score"`) without the corresponding table, page, and verbatim evidence quote.

---

## 7. Lossless Parity & Ingestion Safety Protocol (Rule 27)
- **Strict Prohibition of Ad-Hoc Glue Scripts (Universal Inserter Mandatory):** Agents are strictly forbidden from writing one-off, ad-hoc Python scripts in `scratch/` that construct Excel rows using raw hardcoded value lists (e.g., `[var_name, 999, 999...]`). All Excel row construction and database updates MUST be driven by verified, schema-bound inserters (such as `universal_excel_inserter.py`) where fields are dynamically bound by dictionary keys.
- **Lossless Ingestion Guarantee (Zero Data Drop):** If any subagent extraction output (JSON) contains a valid empirical statistic (Mean, SD, Sample Demographics, or Reliability), that value MUST be faithfully transcribed into the target Excel cell. Under no circumstances may a known extracted numeric value be silently dropped or defaulted to `999`.
- **Pre-Commit Lossless Parity Verification Gate:** Before committing any newly generated or modified Excel extraction sheet, the system MUST execute `verify_ingestion_parity.py` comparing the extraction JSON against the generated Excel sheet. If any valid metric extracted in the JSON is recorded as `999` in Excel, the verification MUST throw a critical assertion error, abort the commit, and quarantine the invalid payload.
- **Heuristic Linter Guard (100% Missing Heuristic):** For all included papers in batch coding sheets, the repository auditor (`linter.py`) checks whether all effect size rows for a given paper have 100% missing (`999`) values for IV Mean/SD and DV Mean/SD. Since over 95% of published correlation tables report Means and SDs, a 100% missing rate triggers an automatic heuristic audit warning to verify whether the source paper's correlation table reported those metrics.

---

## 8. Gatekeeper & Two-Step BSB Sub-dimension Classification Protocol (Rule 28)
- **Theoretical Foundations (Tushman's 2-Step Information Processing Model):** In classic boundary-spanning research (e.g., Tushman, 1977; Tushman & Scanlan, 1981; Sexton, 1995), boundary-spanning behavior (BSB) is fundamentally conceptualized as a **two-step information processing role**:
  1. **External Information Acquisition (Extraunit Communication):** Gathering technical, market, or customer knowledge across organizational or project boundaries.
  2. **Internal Information Dissemination (Intraunit Communication):** Translating, sharing, and disseminating that gathered external knowledge to colleagues within the unit.
- **Mandatory BSB Classification (Col 41):** When a paper empirically operationalizes boundary spanning through this two-step architecture:
  - **Internal Dissemination / Intraunit Communication** (e.g., `Internal Com.` in Sexton 1995) MUST be classified as a **Boundary Spanning Behavior (BSB) sub-dimension in Col 41**, NOT demoted to a Non-BS variable (Col 45).
  - Similarly, in Customer-Oriented BSB (COBSB, e.g., Bettencourt & Brown 2003), **Internal Influence** (communicating customer needs to colleagues and management to improve internal service delivery) MUST be classified as a **BSB sub-dimension in Col 41**.
- **Orthogonal Cartesian Pairing Topology:** When a study measures both the global composite BSB and its discrete external/internal sub-facets (e.g., `BSA`, `External Com.`, `Internal Com.`):
  - Each BSB construct must be orthogonally paired with all substantive Non-BS variables ($N_{\text{BSB}} \times M_{\text{Non-BS}} = K \text{ rows}$).
  - Substantive Non-BS variables (Col 45) include contextual, demographic, attitudinal, stress, and outcome constructs, but exclude BSB sub-dimensions.

---

## 9. Broadened Worker Population Boundary Protocol (Rule 29)
- **Worker Definition (Broadened Inclusion Scope):** The target population for this meta-analysis encompasses all individual workers performing work-related boundary-spanning behaviors (BSB). This officially includes:
  - Formally employed staff, specialists, managers, and executives (salaried or hourly organizational employees).
  - Skilled digital freelancers (e.g., Upwork/platform professionals as in Lalos, 2024), gig workers, and independent contractors performing work across client or organizational networks.
  - Self-employed professionals and entrepreneurs *provided* the study empirically measures their individual interpersonal boundary-spanning behavior (e.g., information scouting, task coordination, external representation across professional or organizational boundaries).
  - **MBA & Professional Graduate Consulting Teams:** MBA students and professional graduate students engaged in applied, client-facing organizational consulting projects or field business engagements where boundary spanning across real client/external stakeholder interfaces is empirically measured (e.g., Marrone et al., 2007).
- **Mandatory Inclusion (`1 = Include`):** Studies investigating individual boundary-spanning behavior among digital freelancers, gig workers, independent contractors, self-employed workers, or MBA/professional graduate consulting teams that provide extractable zero-order effect sizes ($r$) MUST BE INCLUDED (`1 = Include`).
- **Preserved Non-Worker Exclusions (`Code 2 = Non-employee samples`):** The exclusion under `Code 2` is strictly preserved and applied to non-worker populations who are not active labor/workforce participants:
  - **Undergraduate & Classroom Laboratory Simulations:** Pure undergraduate student samples participating in artificial classroom exercises, hypothetical vignettes, or laboratory experimental simulations without real client/organizational boundary spanning (e.g., Baldwin 1990; Lanaj & Hollenbeck 2015; Nasim & Iqbal 2020; Kenda et al. 2021).
  - **Consumer & Citizen Samples:** General consumers, product users, or online forum visitors (e.g., Albert et al. 2019).
  - **Bibliometric / Synthetic Data:** Studies utilizing purely citation records (e.g., Web of Science) without human worker surveys.
- **Level of Analysis & Construct Discriminant Safeguards:**
  - If a study on entrepreneurs or self-employed individuals measures **Work-Life or Work-Family boundary management** rather than organizational/client boundary spanning $\rightarrow$ Exclude under **`Code 1 (No effect size of interest / Construct Mismatch)`**.
  - If a study examines firm-level strategic alliances, inter-firm patenting, or macro MNE networks $\rightarrow$ Exclude under **`Code 3 (Non-individual level)`**.


## 10. 3-Tier Data Hierarchy Protocol (Rule 30)
- **Primary Source (Correlation Matrix):** Always extract Means, SDs, and reliabilities from the primary correlation matrix first.
- **Secondary Source (Descriptive Tables):** If Means or SDs are entirely missing from the correlation matrix, you MUST scan secondary descriptive statistics tables (e.g., Table 1) before declaring them missing.
- **Tertiary Source (In-text Narrative):** If still not found, check the methodology narrative text.
- **Strict Prohibition (No Overwrite):** Under NO circumstances should in-text narrative values overwrite or supersede values explicitly printed in a table.

---

## 11. Meeting-Ready Summary Artifact Formatting Protocol (Rule 31)
Whenever generating a batch summary or deep diagnostic artifact for user/faculty meetings, you MUST strictly follow the canonical format established in `batch_392_to_511_10papers_summary.md`:
- **Zero Graphs / Mermaid Diagrams:** Use ONLY structured Markdown tables and text. Never include Mermaid diagrams or ASCII charts in meeting summary artifacts.
- **Section 1 — Executive Summary Table (`전체 총괄 요약표`):** A unified table covering all evaluated papers (`배치 구분`, `Paper ID`, `제1저자 및 연도`, `출처 / 학술지`, `최종 판정`, `추출 효과크기 / 배제 코드`, `표본 크기 (N) 및 연구 핵심 특징`), followed by total counts of Included papers (total effect size rows) and Excluded papers (by code).
- **Section 2 — 100% Re-Verification Audit Table (when applicable):** A summary table documenting any corrections verified against the source PDFs (`Paper ID`, `재검증 점검 항목`, `이전 코딩값`, `원문 대조 후 최종 확정값`, `원문 근거 위치`).
- **Included Paper Sections (`[포함 논문] Paper [ID] Author (Year)`):**
  1. **Metadata & Design:** Full citation, final judgment, research purpose, sample & design descriptors ($N$, design, country, demographics with `999` specified), verbatim sample quote (strictly zero ellipses `...` per Rule 13), and measurement instrument summary (BSB & Non-BS scales, item counts, Likert ranges, report types, reliabilities, Means, SDs).
  2. **Full Original Correlation Matrix Table (`원문 Table X`):** Complete reproduction of the source paper's descriptive and correlation matrix ($M, SD, \alpha/\text{CR}$, all matrix columns, footnotes, and significance stars) with BSB rows/cells bolded.
  3. **Extracted Effect Sizes Table (`추출된 효과크기 목록`):** A structured table of all extracted BSB $\times$ Non-BS pairs (`행 번호`, `BSB 변수명 (Col 41)`, `상대 Non-BS 변수명 (Col 45)`, `표본 크기 (N)`, `상관계수 (r)`, `원문 셀 값 (Col 50)`).
- **Excluded Paper Sections (`[배제 논문] Paper [ID] Author (Year)`):**
  1. **Metadata & Exclusion Rationale:** Full citation, final judgment & exclusion code, and numbered explanation of why the paper is excluded for meeting defense.
  2. **Original Source Table Proof (`원문 Table X — 배제 근거 표`):** Reproduction or excerpt of the source paper's table (e.g., firm-level matrix for `Code 3` or univariate/regression OR table for `Code 1`) demonstrating why individual-level bivariate correlations ($r$) cannot be extracted.
  3. **Verbatim Exclusion Evidence Quotes:** Exact verbatim quotes with page/footnote coordinates and zero ellipses (`...`).
- **Footer Links (`관련 코딩 시트 파일 링크`):** Direct `file:///` links to the verified `.xlsx` coding sheets in `03_Coding_Sheets/`.

