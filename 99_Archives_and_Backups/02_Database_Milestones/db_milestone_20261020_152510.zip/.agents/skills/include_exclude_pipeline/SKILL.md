---
name: include_exclude_pipeline
description: Orchestrates the automated Real-Swarm pipeline for evaluating inclusion/exclusion criteria in batches of 40.
---

# Skill: Include/Exclude Pipeline Orchestrator

When the user asks you to "run the pipeline", you must act as the Master Orchestrator for the Include/Exclude screening process using Real Subagents. Do NOT use the dummy `run_batch.py` script.

## 1. Batch Payload Generation
- Run `python .agents/skills/include_exclude_pipeline/scripts/swarm_prep.py --batch 40 --excel "target_excel_file_path.xlsx"`
- This script checks the target Excel file and generates a payload file at `scratch/subagents_payload.json` containing up to 40 pending papers.
- If the script outputs that no more pending papers are found, proceed to Step 4 (Reporting).

## 2. Real-Swarm Invocation
- Read the generated `scratch/subagents_payload.json` file.
- Use your `invoke_subagent` tool to spawn the `bsma_reviewer_v4` subagents exactly as defined in the JSON array.
- **Wait** asynchronously for all subagents to finish processing their PDFs and output their verdict JSONs into `scratch/outputs/`.

## 3. Data Injection & Loop
- Once the subagents finish, run `python .agents/skills/include_exclude_pipeline/scripts/swarm_inject.py --excel "target_excel_file_path.xlsx"` to write their verdicts into the Excel sheet and clean up the JSON files.
- After injection completes, **loop back to Step 1** to process the next batch of 40 papers until the Excel queue is completely empty.

## 4. Final Reporting
- Once the Excel queue is completely processed, `swarm_inject.py` outputs the Batch Integrity Report summarizing clean injections, auto-repairs, and quarantine rates.
- All Phase 1 screening match rates and consensus benchmarks across the 701 papers are documented in `04_Reports/Match_Rate_Report.md`.

## 5. Domain Guardrails Reference
Subagents must adhere to [references/screening_rules_core.md](file:///.agents/skills/include_exclude_pipeline/references/screening_rules_core.md).

## 6. Cross-References (Global DNA)
As a domain skill, this file is governed by the global `.agents/AGENTS.md`. When executing this pipeline, you must remember:
- **Core Principle 3 (Automated Github Sync):** After running `swarm_inject.py` successfully, you MUST run git commands to backup the `BSMA_Master_Coding_Sheet.xlsx`.
- **See Screening Rule 8 (Exclusion Coding Protocol) in `references/screening_rules_core.md` and Rule 29 (`Broadened Worker Population Boundary Protocol`) in `.agents/rules/data_integrity.md`.**
- **Rule 13 (Verbatim Quote Injection):** All subagent verdicts must include full verbatim evidence with no ellipsis truncation.
